# Ordner für lange DNA/RNA Sequenzen
